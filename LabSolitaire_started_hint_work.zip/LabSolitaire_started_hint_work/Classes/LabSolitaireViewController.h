// =====================================================================================================================
//  LabSolitaireViewController.h
// =====================================================================================================================


#import <AVFoundation/AVFoundation.h>
#import <UIKit/UIKit.h>
#import "CardEngine.h"


#define kNumCardDrawSounds		4
#define kNumCardPlaceSounds		4

@class LSStackView;


@interface LabSolitaireViewController : UIViewController <CEStackViewDelegate>
{
	LSStackView				*_cellViews[4];	
	LSStackView				*_foundationViews[4];	
	LSStackView				*_tableauViews[8];
	UIButton				*_newButton;
	UIButton				*_undoButton;
	UIButton				*_infoButton;
	UIInterfaceOrientation	_orientation;
	NSTimer					*_putawayTimer;
	NSTimer					*_fadeHintTimer;
	NSInteger				_hintState;
	BOOL					_playedAtleastOneCard;
	BOOL					_gameWon;
	BOOL					_autoPutaway;
	BOOL					_playSounds;
	BOOL					_wasAutoPutaway;
	BOOL					_infoViewIsOpen;
	BOOL					_restrictedDrag;
	AVAudioPlayer			*_shufflePlayer;							// NOTE: NEED TO RELEASE
	AVAudioPlayer			*_cardDrawPlayers[kNumCardDrawSounds];		// NOTE: NEED TO RELEASE
	AVAudioPlayer			*_cardPlacePlayers[kNumCardPlaceSounds];	// NOTE: NEED TO RELEASE
	AVAudioPlayer			*_clickOpenSoundPlayer;						// NOTE: NEED TO RELEASE
	AVAudioPlayer			*_clickCloseSoundPlayer;					// NOTE: NEED TO RELEASE
	AVAudioPlayer			*_undoSoundPlayer;							// NOTE: NEED TO RELEASE
	AVAudioPlayer			*_winSoundPlayer;							// NOTE: NEED TO RELEASE
	UIView					*_currentInfoView;
	UIView					*_currentHintView;
	UIView					*_rotatingView;
	UIView					*_darkView;
	UIView					*_infoView;
	UIView					*_aboutView;
	UIView					*_settingsView;
	UIView					*_rulesView;
	UIView					*_gameOverView;
	UIView					*_overlayingView;
	UIButton				*_autoPutawayButton;
	UIButton				*_playSoundsButton;
	UILabel					*_gamesPlayedLabel;
	UILabel					*_gamesWonLabel;
	UILabel					*_gamesWonPercentageLabel;
	UILabel					*_gamesPlayedLabel2;
	UILabel					*_gamesWonLabel2;
	UILabel					*_gamesWonPercentageLabel2;
	UIView					*_hintFoundationView;
	UIView					*_hintCellsView;
}

@property (nonatomic, retain) IBOutlet UIView	*aboutView;
@property (nonatomic, retain) IBOutlet UIView	*settingsView;
@property (nonatomic, retain) IBOutlet UIView	*rulesView;
@property (nonatomic, retain) IBOutlet UIView	*gameOverView;
@property (nonatomic, retain) IBOutlet UIButton	*autoPutawayButton;
@property (nonatomic, retain) IBOutlet UIButton	*playSoundsButton;
@property (nonatomic, retain) IBOutlet UILabel	*gamesPlayedLabel;
@property (nonatomic, retain) IBOutlet UILabel	*gamesWonLabel;
@property (nonatomic, retain) IBOutlet UILabel	*gamesWonPercentageLabel;
@property (nonatomic, retain) IBOutlet UILabel	*gamesPlayedLabel2;
@property (nonatomic, retain) IBOutlet UILabel	*gamesWonLabel2;
@property (nonatomic, retain) IBOutlet UILabel	*gamesWonPercentageLabel2;
@property (nonatomic, retain) IBOutlet UIView	*hintFoundationView;
@property (nonatomic, retain) IBOutlet UIView	*hintCellsView;

- (void) saveState;
- (void) restoreState;

- (IBAction) info: (id) sender;
- (IBAction) aboutInfo: (id) sender;
- (IBAction) settingsInfo: (id) sender;
- (IBAction) rulesInfo: (id) sender;
- (IBAction) closeInfo: (id) sender;
- (IBAction) toggleAutoPutaway: (id) sender;
- (IBAction) toggleSound: (id) sender;
- (IBAction) resetStats: (id) sender;
- (IBAction) openGameOverView;

@end
