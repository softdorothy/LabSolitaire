// =====================================================================================================================
//  LabSolitaireViewController.m
// =====================================================================================================================


#import <AssertMacros.h>
#import "LabSolitaireViewController.h"
#import "LSStackView.h"


#define DISPLAY_OUTLINE_IN_TABLEAU		0
#define DISPLAY_OUTLINE_FOR_FOUNDATIONS	1


// Portrait layout constants.
#define kPLayoutHOffset				8.0
#define kPLayoutVOffset				100.0
#define kPCardWide					82.0
#define kPCardTall					114.0
#define kPCellFoundationHGap		10.0
#define kPFoundationHOffset			kPLayoutHOffset + 394.0
#define kPTableauHGap				14.0
#define kPTableauVOffset			kPLayoutVOffset + kPCardTall + 20.0
#define kPTableauTall				566.0

// Landscape layout constants.
#define kLLayoutHOffset				143.0
#define kLLayoutVOffset				16.0
#define kLCardWide					82.0
#define kLCardTall					114.0
#define kLCellFoundationHGap		10.0
#define kLFoundationHOffset			kLLayoutHOffset + 387.0
#define kLTableauHGap				13.0
#define kLTableauVOffset			kLLayoutVOffset + kLCardTall + 20.0
#define kLTableauTall				584.0

#define kAnimationDuration			0.3
#define kAnimationDelay				0.2

#define kButtonWide					92.0
#define kButtonTall					45.0

#define kLNewButtonY				188.0
#define kLUndoButtonY				135.0
#define kLInfoButtonY				82.0

#define kPNewButtonY				181.0
#define kPUndoButtonY				128.0
#define kPInfoButtonY				75.0

#define kResetTableAlertTag			1
#define kResetStatsAlertTag			2


enum
{
	kHintNone = 0, 
	kHintMoveCardsToFoundation = 1, 
	kHintMoveCardsToCells = 2
};


@implementation LabSolitaireViewController
// ========================================================================================== LabSolitaireViewController
// ---------------------------------------------------------------------------------------------------------- synthesize

@synthesize aboutView = _aboutView;
@synthesize settingsView = _settingsView;
@synthesize rulesView = _rulesView;
@synthesize gameOverView = _gameOverView;
@synthesize autoPutawayButton = _autoPutawayButton;
@synthesize playSoundsButton = _playSoundsButton;
@synthesize gamesPlayedLabel = _gamesPlayedLabel;
@synthesize gamesWonLabel = _gamesWonLabel;
@synthesize gamesWonPercentageLabel = _gamesWonPercentageLabel;
@synthesize gamesPlayedLabel2 = _gamesPlayedLabel2;
@synthesize gamesWonLabel2 = _gamesWonLabel2;
@synthesize gamesWonPercentageLabel2 = _gamesWonPercentageLabel2;
@synthesize hintFoundationView = _hintFoundationView;
@synthesize hintCellsView = _hintCellsView;

// ------------------------------------------------------------------------------------------ adjustLayoutForOrientation

- (void) adjustLayoutForOrientation: (UIInterfaceOrientation) orientation
{
	CGRect	mainBounds;
	CGRect	buttonFrame;

	mainBounds = [[UIScreen mainScreen] bounds];
	
	if (UIInterfaceOrientationIsPortrait (orientation))
	{
		int		i;
		
		// Adjust cells.
		for (i = 0; i < 4; i++)
			_cellViews[i].frame = CGRectMake (kPLayoutHOffset + (i * (kPCellFoundationHGap + kPCardWide)), kPLayoutVOffset, kPCardWide, kPCardTall);

		// Adjust foundations.
		for (i = 0; i < 4; i++)
			_foundationViews[i].frame = CGRectMake (kPFoundationHOffset + (i * (kPCellFoundationHGap + kPCardWide)), kPLayoutVOffset, kPCardWide, kPCardTall);
		
		// Adjust tableau.
		for (i = 0; i < 8; i++)
			_tableauViews[i].frame = CGRectMake (kPLayoutHOffset + (i * (kPTableauHGap + kPCardWide)), kPTableauVOffset, kPCardWide, kPTableauTall);
		
		buttonFrame = _newButton.frame;
		buttonFrame.origin = CGPointMake (mainBounds.size.width - kButtonWide, mainBounds.size.height - kPNewButtonY);
		_newButton.frame = buttonFrame;
		[_newButton setImage: [UIImage imageNamed: @"NewSelectedP"] forState: UIControlStateHighlighted];
		
		buttonFrame = _undoButton.frame;
		buttonFrame.origin = CGPointMake (mainBounds.size.width - kButtonWide, mainBounds.size.height - kPUndoButtonY);
		_undoButton.frame = buttonFrame;
		[_undoButton setImage: [UIImage imageNamed: @"UndoSelectedP"] forState: UIControlStateHighlighted];
		
		buttonFrame = _infoButton.frame;
		buttonFrame.origin = CGPointMake (mainBounds.size.width - kButtonWide, mainBounds.size.height - kPInfoButtonY);
		_infoButton.frame = buttonFrame;
		[_infoButton setImage: [UIImage imageNamed: @"InfoSelectedP"] forState: UIControlStateHighlighted];
		
		_darkView.frame = mainBounds;
		
		if (_infoView)
		{
			CGRect	frame;
			
			frame = _infoView.frame;
			if (_infoViewIsOpen)
				frame.origin = CGPointMake ((mainBounds.size.width - frame.size.width) / 2.0, mainBounds.size.height - frame.size.height);
			else
				frame.origin = CGPointMake ((mainBounds.size.width - frame.size.width) / 2.0, mainBounds.size.height);
			_infoView.frame = frame;
		}
	}
	else
	{
		int		i;
		
		// Adjust cells.
		for (i = 0; i < 4; i++)
			_cellViews[i].frame = CGRectMake (kLLayoutHOffset + (i * (kLCellFoundationHGap + kLCardWide)), kLLayoutVOffset, kLCardWide, kLCardTall);
		
		// Adjust foundations.
		for (i = 0; i < 4; i++)
			_foundationViews[i].frame = CGRectMake (kLFoundationHOffset + (i * (kLCellFoundationHGap + kLCardWide)), kLLayoutVOffset, kLCardWide, kLCardTall);
		
		// Create tableau.
		for (i = 0; i < 8; i++)
			_tableauViews[i].frame = CGRectMake (kLLayoutHOffset + (i * (kLTableauHGap + kLCardWide)), kLTableauVOffset, kLCardWide, kLTableauTall);
		
		buttonFrame = _newButton.frame;
		buttonFrame.origin = CGPointMake (mainBounds.size.height - kButtonWide, mainBounds.size.width - kLNewButtonY);
		_newButton.frame = buttonFrame;
		[_newButton setImage: [UIImage imageNamed: @"NewSelectedL"] forState: UIControlStateHighlighted];
		
		buttonFrame = _undoButton.frame;
		buttonFrame.origin = CGPointMake (mainBounds.size.height - kButtonWide, mainBounds.size.width - kLUndoButtonY);
		_undoButton.frame = buttonFrame;
		[_undoButton setImage: [UIImage imageNamed: @"UndoSelectedL"] forState: UIControlStateHighlighted];
		
		buttonFrame = _infoButton.frame;
		buttonFrame.origin = CGPointMake (mainBounds.size.height - kButtonWide, mainBounds.size.width - kLInfoButtonY);
		_infoButton.frame = buttonFrame;
		[_infoButton setImage: [UIImage imageNamed: @"InfoSelectedL"] forState: UIControlStateHighlighted];
		
		_darkView.frame = CGRectMake (0.0, 0.0, mainBounds.size.height, mainBounds.size.width);
		
		if (_infoView)
		{
			CGRect	frame;
			
			frame = _infoView.frame;
			if (_infoViewIsOpen)
				frame.origin = CGPointMake ((mainBounds.size.height - frame.size.width) / 2.0, mainBounds.size.width - frame.size.height);
			else
				frame.origin = CGPointMake ((mainBounds.size.height - frame.size.width) / 2.0, mainBounds.size.width);
			_infoView.frame = frame;
		}
	}
}

// --------------------------------------------------------------------------------------------------------- displayHint

- (void) displayHint
{
	CGRect	frame;
	CGFloat	wide;
	
	// Display hint.
	switch (_hintState)
	{
		case kHintMoveCardsToFoundation:
		_hintFoundationView.alpha = 1.0;
		frame = _hintFoundationView.frame;
		wide = CGRectGetMaxX (_foundationViews[3].frame) - CGRectGetMinX (_foundationViews[0].frame);
		frame.origin.x = CGRectGetMinX (_foundationViews[0].frame) + ((wide - frame.size.width) / 2.0);
		frame.origin.y = CGRectGetMinY (_foundationViews[0].frame) + ((CGRectGetHeight (_foundationViews[0].frame) - frame.size.height) / 2.0);
		_hintFoundationView.frame = frame;
		[self.view addSubview: _hintFoundationView];
		_currentHintView = _hintFoundationView;
		break;
		
		case kHintMoveCardsToCells:
		_hintCellsView.alpha = 1.0;
		frame = _hintCellsView.frame;
		wide = CGRectGetMaxX (_cellViews[3].frame) - CGRectGetMinX (_cellViews[0].frame);
		frame.origin.x = CGRectGetMinX (_cellViews[0].frame) + ((wide - frame.size.width) / 2.0);
		frame.origin.y = CGRectGetMinY (_cellViews[0].frame) + ((CGRectGetHeight (_cellViews[0].frame) - frame.size.height) / 2.0);
		_hintCellsView.frame = frame;
		[self.view addSubview: _hintCellsView];
		_currentHintView = _hintCellsView;
		break;
	}
	
	_fadeHintTimer = [NSTimer scheduledTimerWithTimeInterval: 8.0 target: self 
				selector: @selector (fadeHint:) userInfo: nil repeats: NO];
}

#pragma mark ------ card routines
// --------------------------------------------------------------------------------------------- noteAtleastOneCardMoved

- (void) noteAtleastOneCardMoved
{
	NSUserDefaults	*defaults;
	NSNumber		*number;
	NSInteger		gamesPlayed = 0;
	
	// Get standard defaults.
	defaults = [NSUserDefaults standardUserDefaults];
	
	// Log another game begun.
	// Get number of games played from the prefs, increment.
	number = [defaults objectForKey: @"GamesPlayed"];
	if (number)
		gamesPlayed = [number integerValue];
	gamesPlayed = gamesPlayed + 1;
	
	// Store new number of games played.
	[defaults setObject: [NSNumber numberWithInteger: gamesPlayed] forKey: @"GamesPlayed"];
	[defaults synchronize];
	
	// Count this game only once.
	_playedAtleastOneCard = YES;
}

// ---------------------------------------------------------------------------------------- determineIfCardsCanBePutAway

- (void) determineIfCardsCanBePutAway
{
	BOOL	didFindCard;
	
	do
	{
		int		i;
		
		didFindCard = NO;
		for (i = 0; i < 8; i++)
		{
			CECard	*topSrcCard;
			int		k;
			
			// Top card of tableau.
			topSrcCard = [[_tableauViews[i] stack] topCard];
			for (k = 0; k < 4; k++)
			{
				CECard	*topDestCard;
				
				// Top card of foundation.
				topDestCard = [[_foundationViews[k] stack] topCard];
				if (topDestCard == nil)
				{
					if ((topSrcCard.suit == k) && (topSrcCard.rank == kCERankAce))
					{
						[_tableauViews[i] dealTopCardToStackView: _foundationViews[k] faceUp: YES duration: kAnimationDuration];
						[[NSRunLoop currentRunLoop] runUntilDate: [NSDate dateWithTimeIntervalSinceNow: kAnimationDelay]];
						didFindCard = YES;
					}
				}
				else if ((topSrcCard.suit == topDestCard.suit) && (topSrcCard.rank == (topDestCard.rank + 1)))
				{
					[_tableauViews[i] dealTopCardToStackView: _foundationViews[k] faceUp: YES duration: kAnimationDuration];
					[[NSRunLoop currentRunLoop] runUntilDate: [NSDate dateWithTimeIntervalSinceNow: kAnimationDelay]];
					didFindCard = YES;
				}
			}
		}
		
		for (i = 0; i < 4; i++)
		{
			CECard	*topSrcCard;
			int		k;
			
			// Top card of tableau.
			topSrcCard = [[_cellViews[i] stack] topCard];
			for (k = 0; k < 4; k++)
			{
				CECard	*topDestCard;
				
				// Top card of foundation.
				topDestCard = [[_foundationViews[k] stack] topCard];
				if (topDestCard == nil)
				{
					if ((topSrcCard.suit == k) && (topSrcCard.rank == kCERankAce))
					{
						[_cellViews[i] dealTopCardToStackView: _foundationViews[k] faceUp: YES duration: kAnimationDuration];
						[[NSRunLoop currentRunLoop] runUntilDate: [NSDate dateWithTimeIntervalSinceNow: kAnimationDelay]];
						didFindCard = YES;
					}
				}
				else if ((topSrcCard.suit == topDestCard.suit) && (topSrcCard.rank == (topDestCard.rank + 1)))
				{
					[_cellViews[i] dealTopCardToStackView: _foundationViews[k] faceUp: YES duration: kAnimationDuration];
					[[NSRunLoop currentRunLoop] runUntilDate: [NSDate dateWithTimeIntervalSinceNow: kAnimationDelay]];
					didFindCard = YES;
				}
			}
		}
	}
	while (didFindCard == YES);
}

// -------------------------------------------------------------------------------------------------- allCardsArePutAway

- (BOOL) allCardsArePutAway
{
	return (([[_foundationViews[0] stack] numberOfCards] == 13) && ([[_foundationViews[1] stack] numberOfCards] == 13) && 
			([[_foundationViews[2] stack] numberOfCards] == 13) && ([[_foundationViews[2] stack] numberOfCards] == 13));
}

// ------------------------------------------------------------------------------------------------- countOfCardsOnTable

- (NSInteger) countOfCardsOnTable
{
	NSInteger	i;
	NSInteger	count = 0;
	
	for (i = 0; i < 4; i++)
		count = count + _cellViews[i].stack.numberOfCards;

	for (i = 0; i < 4; i++)
		count = count + _foundationViews[i].stack.numberOfCards;

	for (i = 0; i < 8; i++)
		count = count + _tableauViews[i].stack.numberOfCards;
	
	return count;
}

// ------------------------------------------------------------------------------------------------------ checkGameState

- (void) checkGameState
{
	// NOP.
	if (_gameWon)
		return;
	
	if ([self allCardsArePutAway])
	{
		NSUserDefaults	*defaults;
		NSNumber		*number;
		NSInteger		gamesPlayed = 0;
		NSInteger		gamesWon = 0;
		
		_gameWon = YES;
		_hintState = kHintNone;
		
		// Get standard defaults.
		defaults = [NSUserDefaults standardUserDefaults];
		
		// Get number of games played from the prefs, increment.
		number = [defaults objectForKey: @"GamesPlayed"];
		if (number)
			gamesPlayed = [number integerValue];
		
		number = [defaults objectForKey: @"GamesWon"];
		if (number)
			gamesWon = [number integerValue];
		gamesWon = gamesWon + 1;
		
		// Store new number of games won.
		[defaults setObject: [NSNumber numberWithInteger: gamesWon] forKey: @"GamesWon"];
		[defaults synchronize];
		
		// Display number of games won.
		[self openGameOverView];
	}
}

// ----------------------------------------------------------------------------------------------------------- saveState

- (void) saveState
{
	// Determine if we have a game in progress.
	if (([[_foundationViews[0] stack] numberOfCards] < 13) || ([[_foundationViews[1] stack] numberOfCards] < 13) || 
			([[_foundationViews[2] stack] numberOfCards] < 13) || ([[_foundationViews[3] stack] numberOfCards] < 13))
	{
		[[NSUserDefaults standardUserDefaults] setBool: YES forKey: @"SavedGame"];
		[(CETableView *) self.view archiveStackStateWithIdentifier: @"LabSolitaire"];
		[[NSUserDefaults standardUserDefaults] setBool: _playedAtleastOneCard forKey: @"PlayedAtleastOneCard"];
	}
	else
	{
		[[NSUserDefaults standardUserDefaults] setBool: NO forKey: @"SavedGame"];
		[[NSUserDefaults standardUserDefaults] setBool: NO forKey: @"PlayedAtleastOneCard"];
	}
}

// ---------------------------------------------------------------------------------------------------------- resetTable

- (void) resetTable: (id) sender
{
	int			i;
	CEStack		*deck;
	
	// A game has begun but no card yet has been touched.
	_playedAtleastOneCard = NO;
	_gameWon = NO;
	
	// Remove all cards.
	for (i = 0; i < 4; i++)
		[[_cellViews[i] stack] removeAllCards];
	for (i = 0; i < 4; i++)
		[[_foundationViews[i] stack] removeAllCards];
	for (i = 0; i < 8; i++)
		[[_tableauViews[i] stack] removeAllCards];
	
	// Clear Undo actions.
	[[CETableView sharedCardUndoManager] removeAllActions];
	
	// Create deck of cards, shuffle.
	deck = [CEStack deckOfCards];
	[deck shuffle];
	
	// Initial card layout.
	for (i = 0; i < 52; i++)
	{
		CECard	*topCard;
		
		// Add top card to tableau, remove from deck.
		topCard = [deck topCard];
		topCard.faceUp = YES;
		[topCard randomizeTransform];
		[[_tableauViews[i % 8] stack] addCard: topCard];
		[deck removeCard: topCard];
	}
	
	_hintState = kHintMoveCardsToFoundation;
	
	// Fire off timer to check for cards that can be put up in the foundation.
	if (_autoPutaway)
	{
		_putawayTimer = [NSTimer scheduledTimerWithTimeInterval: 1.0 target: self 
				selector: @selector (putawayTimer:) userInfo: nil repeats: NO];
	}
	else
	{
		if (_hintState == kHintMoveCardsToFoundation)
			[self displayHint];
	}
}

// -------------------------------------------------------------------------------------------------------- restoreState

- (void) restoreState
{
	// Initial card layout.
	if ([[NSUserDefaults standardUserDefaults] boolForKey: @"SavedGame"] == YES)
	{
		BOOL	success;
		
		success = [(CETableView *) self.view restoreStackStateWithIdentifier: @"LabSolitaire"];
		_playedAtleastOneCard = [[NSUserDefaults standardUserDefaults] boolForKey: @"PlayedAtleastOneCard"];
		
		// Sanity check.
		if ((success == NO) || ([self countOfCardsOnTable] != 52))
			[self resetTable: nil];
	}
	else
	{
		[self resetTable: nil];
	}
}

#pragma mark ------ actions
// ---------------------------------------------------------------------------------------------------------------- undo

- (void) new: (id) sender
{
	if (_playSounds)
		[_clickOpenSoundPlayer play];
	
	if ((_playedAtleastOneCard == NO) || ([self allCardsArePutAway]))
	{
		if (_playSounds)
			[_shufflePlayer play];
		 
		// If the game is over, no need for alert.
		[self resetTable: nil];
	}
	else
	{
		UIAlertView	*alert;
		
		// A game is in progress, allow the user to cancel the new game.
		alert = [[UIAlertView alloc] initWithTitle: @"New Game" 
				message: @"If you start a new game, this game will be abandoned." 
				delegate: self cancelButtonTitle: @"Cancel" otherButtonTitles: @"New Game", nil];
		alert.tag = kResetTableAlertTag;
		[alert show];
		[alert release];
	}
}

// ---------------------------------------------------------------------------------------------------------------- undo

- (void) undo: (id) sender
{
	if (_playSounds)
		[_undoSoundPlayer play];
	
	[[CETableView sharedCardUndoManager] undo];
}

// ---------------------------------------------------------------------------------------------------------------- info

- (void) info: (id) sender
{
	CGRect		mainBounds;
	BOOL		portrait;
	CGRect		frame;
	
	if (_playSounds)
		[_clickOpenSoundPlayer play];
	
	_infoViewIsOpen = YES;
	_wasAutoPutaway = _autoPutaway;
	
	// Get main bounds and orientation.
	mainBounds = [[UIScreen mainScreen] bounds];
	portrait = UIInterfaceOrientationIsPortrait ([UIApplication sharedApplication].statusBarOrientation);
	
	// Create dark view to obscure card table. Initially it has a clear background.
	// Add as subview to card table.
	if (_infoView == nil)
	{
		// Create view to contain the paper tablet. Initially position it below the bottom edge of display.
		// Add as subview to dark view.
		_infoView = [[UIImageView alloc] initWithImage: [UIImage imageNamed: @"PaperTablet"]];
		_infoView.userInteractionEnabled = YES;
		frame = _infoView.frame;
		if (portrait)
			frame.origin = CGPointMake ((mainBounds.size.width - frame.size.width) / 2.0, mainBounds.size.height);
		else
			frame.origin = CGPointMake ((mainBounds.size.height - frame.size.width) / 2.0, mainBounds.size.width);
		_infoView.frame = frame;
		[_darkView addSubview: _infoView];
	}
	
	// Initially begin with "about view" being displayed.
	_aboutView.alpha = 1.0;
	[_infoView addSubview: _aboutView];
	_currentInfoView = _aboutView;
	
	// Capture touch events.
	_darkView.userInteractionEnabled = YES;
	
	// Animate-in the view sliding in while the dark view becomes darker.
	[UIView beginAnimations: @"SlideInInfoView" context: nil];
	[UIView setAnimationDuration: 0.5];
	_darkView.backgroundColor = [UIColor colorWithWhite: 0.0 alpha: 0.75];
	frame = _infoView.frame;
	if (portrait)
		frame.origin = CGPointMake ((mainBounds.size.width - frame.size.width) / 2.0, mainBounds.size.height - frame.size.height);
	else
		frame.origin = CGPointMake ((mainBounds.size.height - frame.size.width) / 2.0, mainBounds.size.width - frame.size.height);
	_infoView.frame = frame;
	[UIView commitAnimations];
}

// ----------------------------------------------------------------------------------------------------------- aboutInfo

- (void) aboutInfo: (id) sender
{
	if (_playSounds)
		[_clickOpenSoundPlayer play];
	
	// Switch to display the "about view".
	_aboutView.alpha = 0.0;
	[_infoView addSubview: _aboutView];
	
	// Animate-out the view sliding out while the dark view becomes clear again.
	[UIView beginAnimations: @"FadeOutInfoSubview" context: _aboutView];
	[UIView setAnimationDelegate: self];
	[UIView setAnimationDidStopSelector: @selector (animationStopped:finished:context:)];
	_aboutView.alpha = 1.0;
	_currentInfoView.alpha = 0.0;
	[UIView commitAnimations];
}

// -------------------------------------------------------------------------------------------------------- settingsInfo

- (void) settingsInfo: (id) sender
{
	NSUserDefaults	*defaults;
	NSNumber		*number;
	NSInteger		gamesPlayed = 0;
	NSInteger		gamesWon = 0;
	
	if (_playSounds)
		[_clickOpenSoundPlayer play];
	
	// Switch to display the "settings view".
	_settingsView.alpha = 0.0;
	[_infoView addSubview: _settingsView];
	
	// Buttons should reflect user preferences.
	if (_autoPutaway)
		[_autoPutawayButton setImage: [UIImage imageNamed: @"CheckYes"] forState: UIControlStateNormal];
	else
		[_autoPutawayButton setImage: [UIImage imageNamed: @"CheckNo"] forState: UIControlStateNormal];
	
	if (_playSounds)
		[_playSoundsButton setImage: [UIImage imageNamed: @"CheckYes"] forState: UIControlStateNormal];
	else
		[_playSoundsButton setImage: [UIImage imageNamed: @"CheckNo"] forState: UIControlStateNormal];
	
	// Get standard defaults.
	defaults = [NSUserDefaults standardUserDefaults];
	number = [defaults objectForKey: @"GamesPlayed"];
	if (number)
		gamesPlayed = [number integerValue];
	number = [defaults objectForKey: @"GamesWon"];
	if (number)
		gamesWon = [number integerValue];
	
	// Reflect game statistics.
	_gamesPlayedLabel.text = [NSString stringWithFormat: @"%d", gamesPlayed];
	_gamesWonLabel.text = [NSString stringWithFormat: @"%d", gamesWon];
	if (gamesPlayed == 0)
		_gamesWonPercentageLabel.text = @"-";
	else
		_gamesWonPercentageLabel.text = [NSString stringWithFormat: @"%d%%", (gamesWon * 100) / gamesPlayed];
	
	// Animate-out the view sliding out while the dark view becomes clear again.
	[UIView beginAnimations: @"FadeOutInfoSubview" context: _settingsView];
	[UIView setAnimationDelegate: self];
	[UIView setAnimationDidStopSelector: @selector (animationStopped:finished:context:)];
	_settingsView.alpha = 1.0;
	_currentInfoView.alpha = 0.0;
	[UIView commitAnimations];
}

// ----------------------------------------------------------------------------------------------------------- rulesInfo

- (void) rulesInfo: (id) sender
{
	if (_playSounds)
		[_clickOpenSoundPlayer play];
	
	// Switch to display the "rules view".
	_rulesView.alpha = 0.0;
	[_infoView addSubview: _rulesView];
	
	// Animate-out the view sliding out while the dark view becomes clear again.
	[UIView beginAnimations: @"FadeOutInfoSubview" context: _rulesView];
	[UIView setAnimationDelegate: self];
	[UIView setAnimationDidStopSelector: @selector (animationStopped:finished:context:)];
	_rulesView.alpha = 1.0;
	_currentInfoView.alpha = 0.0;
	[UIView commitAnimations];
}

// ----------------------------------------------------------------------------------------------------------- closeInfo

- (void) closeInfo: (id) sender
{
	CGRect		mainBounds;
	BOOL		portrait;
	CGRect		frame;
	
	if (_playSounds)
		[_clickCloseSoundPlayer play];
	
	mainBounds = [[UIScreen mainScreen] bounds];
	portrait = UIInterfaceOrientationIsPortrait ([UIApplication sharedApplication].statusBarOrientation);
	
	// No longer capture touch events.
	_darkView.userInteractionEnabled = NO;
	
	// Animate-out the view sliding out while the dark view becomes clear again.
	[UIView beginAnimations: @"SlideOutInfoView" context: nil];
	[UIView setAnimationDuration: 0.5];
	[UIView setAnimationDelegate: self];
	[UIView setAnimationDidStopSelector: @selector (animationStopped:finished:context:)];
	_darkView.backgroundColor = [UIColor colorWithWhite: 0.0 alpha: 0.0];
	frame = _infoView.frame;
	if (portrait)
		frame.origin = CGPointMake ((mainBounds.size.width - frame.size.width) / 2.0, mainBounds.size.height);
	else
		frame.origin = CGPointMake ((mainBounds.size.height - frame.size.width) / 2.0, mainBounds.size.width);
	_infoView.frame = frame;
	[UIView commitAnimations];
}

// --------------------------------------------------------------------------------------------------- toggleAutoPutaway

- (void) toggleAutoPutaway: (id) sender
{
	NSUserDefaults	*defaults;
	
	// Toggle preference.
	_autoPutaway = !_autoPutaway;
	
	// Store auto-putaway preference.
	defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject: [NSNumber numberWithBool: _autoPutaway] forKey: @"AutoPutaway"];
	[defaults synchronize];
	
	// Sound effect.
	if ((_playSounds) && (_autoPutaway == YES))
		[_clickOpenSoundPlayer play];
	if ((_playSounds) && (_autoPutaway == NO))
		[_clickCloseSoundPlayer play];
	
	// Update UI.
	if (_autoPutaway)
		[sender setImage: [UIImage imageNamed: @"CheckYes"] forState: UIControlStateNormal];
	else
		[sender setImage: [UIImage imageNamed: @"CheckNo"] forState: UIControlStateNormal];
}

// --------------------------------------------------------------------------------------------------------- toggleSound

- (void) toggleSound: (id) sender
{
	NSUserDefaults	*defaults;
	
	// Toggle preference.
	_playSounds = !_playSounds;
	
	// Store play-sounds preference.
	defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject: [NSNumber numberWithBool: _playSounds] forKey: @"PlaySounds"];
	[defaults synchronize];

	// Sound effect.
	if (_playSounds)
		[_clickOpenSoundPlayer play];
	
	// Update UI.
	if (_playSounds)
		[sender setImage: [UIImage imageNamed: @"CheckYes"] forState: UIControlStateNormal];
	else
		[sender setImage: [UIImage imageNamed: @"CheckNo"] forState: UIControlStateNormal];
}

// ---------------------------------------------------------------------------------------------------------- resetStats

- (void) resetStats: (id) sender
{
	UIAlertView	*alert;
	
	// Sound effect.
	if (_playSounds)
		[_clickOpenSoundPlayer play];
	
	// A game is in progress, allow the user to cancel the new game.
	alert = [[UIAlertView alloc] initWithTitle: @"Reset Statistics" 
			message: @"Reseting the statistics will clear your game playing history." 
			delegate: self cancelButtonTitle: @"Cancel" otherButtonTitles: @"Reset", nil];
	alert.tag = kResetStatsAlertTag;
	[alert show];
	[alert release];
}

// ---------------------------------------------------------------------------------------------------- openGameOverView

- (void) openGameOverView
{
	CGRect			mainBounds;
	BOOL			portrait;
	CGRect			frame;
	NSUserDefaults	*defaults;
	NSNumber		*number;
	NSInteger		gamesPlayed = 0;
	NSInteger		gamesWon = 0;
	
	_infoViewIsOpen = YES;
	_wasAutoPutaway = _autoPutaway;
	
	// Get main bounds and orientation.
	mainBounds = [[UIScreen mainScreen] bounds];
	portrait = UIInterfaceOrientationIsPortrait ([UIApplication sharedApplication].statusBarOrientation);
	
	// Create dark view to obscure card table. Initially it has a clear background.
	// Add as subview to card table.
	if (_infoView == nil)
	{
		// Create view to contain the paper tablet. Initially position it below the bottom edge of display.
		// Add as subview to dark view.
		_infoView = [[UIImageView alloc] initWithImage: [UIImage imageNamed: @"PaperTablet"]];
		_infoView.userInteractionEnabled = YES;
		frame = _infoView.frame;
		if (portrait)
			frame.origin = CGPointMake ((mainBounds.size.width - frame.size.width) / 2.0, mainBounds.size.height);
		else
			frame.origin = CGPointMake ((mainBounds.size.height - frame.size.width) / 2.0, mainBounds.size.width);
		_infoView.frame = frame;
		[_darkView addSubview: _infoView];
	}
	
	// Add "Game Over" view.
	[_infoView addSubview: _gameOverView];
	_currentInfoView = _gameOverView;
	
	// Get standard defaults.
	defaults = [NSUserDefaults standardUserDefaults];
	number = [defaults objectForKey: @"GamesPlayed"];
	if (number)
		gamesPlayed = [number integerValue];
	number = [defaults objectForKey: @"GamesWon"];
	if (number)
		gamesWon = [number integerValue];
	
	// Reflect game statistics.
	_gamesPlayedLabel2.text = [NSString stringWithFormat: @"%d", gamesPlayed];
	_gamesWonLabel2.text = [NSString stringWithFormat: @"%d", gamesWon];
	_gamesWonPercentageLabel2.text = [NSString stringWithFormat: @"%d%%", (gamesWon * 100) / gamesPlayed];
	
	// Capture touch events.
	_darkView.userInteractionEnabled = YES;
	
	// Animate-in the view sliding in while the dark view becomes darker.
	[UIView beginAnimations: @"SlideInInfoView" context: nil];
	[UIView setAnimationDuration: 0.5];
	[UIView setAnimationDelegate: self];
	[UIView setAnimationDidStopSelector: @selector (animationStopped:finished:context:)];
	_darkView.backgroundColor = [UIColor colorWithWhite: 0.0 alpha: 0.75];
	frame = _infoView.frame;
	if (portrait)
		frame.origin = CGPointMake ((mainBounds.size.width - frame.size.width) / 2.0, mainBounds.size.height - frame.size.height);
	else
		frame.origin = CGPointMake ((mainBounds.size.height - frame.size.width) / 2.0, mainBounds.size.width - frame.size.height);
	_infoView.frame = frame;
	[UIView commitAnimations];
}

// ----------------------------------------------------------------------------------- animationDidStop:finished:context

- (void) animationStopped: (NSString *) animationID finished: (NSNumber *) finished context: (void *) context
{
	if ([animationID isEqualToString: @"SlideInInfoView"])
	{
		if (_currentInfoView == _gameOverView)
		{
			// Player won sound.
			if (_playSounds)
				[_winSoundPlayer play];
		}
	}
	else if ([animationID isEqualToString: @"SlideOutInfoView"])
	{
		_infoViewIsOpen = NO;
		
		if (_currentInfoView)
		{
			[_currentInfoView removeFromSuperview];
			_currentInfoView = nil;
		}
		
		// Fire off auto-putaway timer if the user enabled it.
		if ((_wasAutoPutaway != _autoPutaway) && (_autoPutaway))
		{
			_putawayTimer = [NSTimer scheduledTimerWithTimeInterval: 1.0 target: self selector: 
					@selector (putawayTimer:) userInfo: nil repeats: NO];
		}
		
		// Start new game.
		if (_gameWon)
		{
			// Shuffle sound.
			if (_playSounds)
				[_shufflePlayer play];
			
			// Deal new hand.
			[self resetTable: nil];
		}
	}
	else if ([animationID isEqualToString: @"FadeOutInfoSubview"])
	{
		[_currentInfoView removeFromSuperview];
		_currentInfoView = context;
	}
	else if ([animationID isEqualToString: @"FadeOutHint"])
	{
		[_currentHintView removeFromSuperview];
		_currentHintView = nil;
	}
}

#pragma mark ------ view controller methods
// --------------------------------------------------------------------------------------------------------- viewDidLoad

- (void) viewDidLoad
{
	NSUserDefaults	*defaults;
	NSNumber		*number;
	int				i;
	CGRect			mainBounds;
	NSURL			*audioURL;
	NSError			*error;
	
	// Store orientation.
	_orientation = self.interfaceOrientation;
	
	// Get standard defaults, what is the user preference for auto-putaway.
	defaults = [NSUserDefaults standardUserDefaults];
	number = [defaults objectForKey: @"AutoPutaway"];
	if (number)
		_autoPutaway = [number boolValue];
	else
		_autoPutaway = YES;
	
	// What is the user preference for sound playback?
	defaults = [NSUserDefaults standardUserDefaults];
	number = [defaults objectForKey: @"PlaySounds"];
	if (number)
		_playSounds = [number boolValue];
	else
		_playSounds = YES;
	
	// Assign portrait and landscape images.
	[(CETableView *) self.view setPortraitImagePath: @"TablePortrait"];
	[(CETableView *) self.view setLandscapeImagePath: @"TableLandscape"];
	
	// Create cells.
	for (i = 0; i < 4; i++)
	{
		_cellViews[i] = [[LSStackView alloc] initWithFrame: 
				CGRectMake (kPLayoutHOffset + (i * (kPCellFoundationHGap + kPCardWide)), kPLayoutVOffset, kPCardWide, kPCardTall)];
		[_cellViews[i] setCardSize: kCardSizeLarge];
		[_cellViews[i] setLayout: kCEStackViewLayoutStacked];
		[_cellViews[i] setBorderColor: [UIColor colorWithWhite: 0.0 alpha: 0.22]];
		[_cellViews[i] setFillColor: nil];
		[_cellViews[i] setLabelColor: [UIColor colorWithWhite: 0.0 alpha: 0.22]];
		[_cellViews[i] setLabelFont: [UIFont fontWithName: @"Arial" size: 32.0]];
		[_cellViews[i] setLabel: @"Free"];
		[_cellViews[i] setTag: i];
		[_cellViews[i] setDelegate: self];
		[_cellViews[i] setIdentifier: @"Cell"];
		[_cellViews[i] setArchiveIdentifier: [NSString stringWithFormat: @"Cell%d", i]];
		[(CETableView *) self.view addSubview: _cellViews[i]];
		[_cellViews[i] release];
	}
	
	// Create foundations.
	for (i = 0; i < 4; i++)
	{
		_foundationViews[i] = [[LSStackView alloc] initWithFrame: 
				CGRectMake (kPFoundationHOffset + (i * (kPCellFoundationHGap + kPCardWide)), kPLayoutVOffset, kPCardWide, kPCardTall)];
		[_foundationViews[i] setCardSize: kCardSizeLarge];
		[_foundationViews[i] setLayout: kCEStackViewLayoutStacked];
#if DISPLAY_OUTLINE_FOR_FOUNDATIONS
		[_foundationViews[i] setBorderColor: [UIColor colorWithWhite: 0.0 alpha: 0.22]];
		[_foundationViews[i] setFillColor: nil];
		[_foundationViews[i] setLabelColor: [UIColor colorWithWhite: 0.0 alpha: 0.22]];
#else	// DISPLAY_OUTLINE_FOR_FOUNDATIONS
		[_foundationViews[i] setBorderColor: nil];
		[_foundationViews[i] setFillColor: [UIColor colorWithWhite: 0.0 alpha: 0.16]];
		[_foundationViews[i] setLabelColor: [UIColor colorWithWhite: 0.0 alpha: 0.14]];
#endif	// DISPLAY_OUTLINE_FOR_FOUNDATIONS
		[_foundationViews[i] setLabelFont: [UIFont fontWithName: @"Arial" size: 64.0]];
		[_foundationViews[i] setLabel: [CECard stringForSuit: i]];
		[_foundationViews[i] setTag: i];
		[_foundationViews[i] setDelegate: self];
		[_foundationViews[i] setIdentifier: @"Foundation"];
		[_foundationViews[i] setArchiveIdentifier: [NSString stringWithFormat: @"Foundation%d", i]];
		[(CETableView *) self.view addSubview: _foundationViews[i]];
		[_foundationViews[i] release];
	}
	
	// Create tableau.
	for (i = 0; i < 8; i++)
	{
		_tableauViews[i] = [[LSStackView alloc] initWithFrame: 
				CGRectMake (kPLayoutHOffset + (i * (kPTableauHGap + kPCardWide)), kPTableauVOffset, kPCardWide, kPTableauTall)];
		[_tableauViews[i] setCardSize: kCardSizeLarge];
		[_tableauViews[i] setLayout: kCEStackViewLayoutColumn];
#if DISPLAY_OUTLINE_IN_TABLEAU
		[_tableauViews[i] setBorderColor: [UIColor colorWithWhite: 0.0 alpha: 0.22]];
		[_tableauViews[i] setFillColor: nil];
		[_tableauViews[i] setLabelColor: [UIColor colorWithWhite: 0.0 alpha: 0.22]];
		[_tableauViews[i] setLabelFont: [UIFont fontWithName: @"Arial" size: 32.0]];
		[_tableauViews[i] setLabel: @"Any"];
#else	// DISPLAY_OUTLINE_IN_TABLEAU
		[_tableauViews[i] setBorderColor: nil];
		[_tableauViews[i] setFillColor: nil];
#endif	// DISPLAY_OUTLINE_IN_TABLEAU
		[_tableauViews[i] setTag: i];
		[_tableauViews[i] setDelegate: self];
		[_tableauViews[i] setIdentifier: @"Tableau"];
		[_tableauViews[i] setArchiveIdentifier: [NSString stringWithFormat: @"Tableau%d", i]];
		[_tableauViews[i] setOrderly: NO];
		[(CETableView *) self.view addSubview: _tableauViews[i]];
		[_tableauViews[i] release];
	}
	
	// Layout the buttons.
	mainBounds = [[UIScreen mainScreen] bounds];
	
	// New button.
	_newButton = [[UIButton alloc] initWithFrame: CGRectMake (mainBounds.size.width - kButtonWide, mainBounds.size.height - kPNewButtonY, kButtonWide, kButtonTall)];
	[_newButton setImage: [UIImage imageNamed: @"NewSelectedP"] forState: UIControlStateHighlighted];
	[_newButton addTarget: self action: @selector (new:) forControlEvents: UIControlEventTouchUpInside];
	[self.view addSubview: _newButton];
	
	// Undo button.
	_undoButton = [[UIButton alloc] initWithFrame: CGRectMake (mainBounds.size.width - kButtonWide, mainBounds.size.height - kPUndoButtonY, kButtonWide, kButtonTall)];
	[_undoButton setImage: [UIImage imageNamed: @"UndoSelectedP"] forState: UIControlStateHighlighted];
	[_undoButton addTarget: self action: @selector (undo:) forControlEvents: UIControlEventTouchUpInside];
	[self.view addSubview: _undoButton];
	
	// Info button.
	_infoButton = [[UIButton alloc] initWithFrame: CGRectMake (mainBounds.size.width - kButtonWide, mainBounds.size.height - kPInfoButtonY, kButtonWide, kButtonTall)];
	[_infoButton setImage: [UIImage imageNamed: @"InfoSelectedP"] forState: UIControlStateHighlighted];
	[_infoButton addTarget: self action: @selector (info:) forControlEvents: UIControlEventTouchUpInside];
	[self.view addSubview: _infoButton];
	
	// Create "dark view" and lay over the entire card table and cards. It is only used to fade out the card table 
	// when the "Info" view is put up. It ignores user interaction.
	_darkView = [[UIView alloc] initWithFrame: mainBounds];
	_darkView.backgroundColor = [UIColor colorWithWhite: 0.0 alpha: 0.0];
	_darkView.userInteractionEnabled = NO;
	[self.view addSubview: _darkView];
	
	// Indicate the dark view as the overlaying view. This prevetns card animation from happening above of this view.
	_overlayingView = _darkView;
	
	// Load sounds.
	audioURL = [NSURL fileURLWithPath: [[NSBundle mainBundle] pathForResource: @"Shuffle" ofType: @"wav"]];
	_shufflePlayer = [[AVAudioPlayer alloc] initWithContentsOfURL: audioURL error: &error];
	require (_shufflePlayer, skipAudio);
	[_shufflePlayer prepareToPlay];
	
	// Load "draw card" sounds.
	for (i = 0; i < kNumCardDrawSounds; i++)
	{
		audioURL = [NSURL fileURLWithPath: [[NSBundle mainBundle] pathForResource: [NSString stringWithFormat: @"CardDraw%d", i] ofType: @"wav"]];
		_cardDrawPlayers[i] = [[AVAudioPlayer alloc] initWithContentsOfURL: audioURL error: &error];
		require (_cardDrawPlayers[i], skipAudio);
		[_cardDrawPlayers[i] prepareToPlay];
	}

	// Load "place card" sounds.
	for (i = 0; i < kNumCardPlaceSounds; i++)
	{
		audioURL = [NSURL fileURLWithPath: [[NSBundle mainBundle] pathForResource: [NSString stringWithFormat: @"CardPlace%d", i] ofType: @"wav"]];
		_cardPlacePlayers[i] = [[AVAudioPlayer alloc] initWithContentsOfURL: audioURL error: &error];
		require (_cardPlacePlayers[i], skipAudio);
		[_cardPlacePlayers[i] prepareToPlay];
	}
	
	// Click sounds.
	audioURL = [NSURL fileURLWithPath: [[NSBundle mainBundle] pathForResource: @"ClickOpen" ofType: @"wav"]];
	_clickOpenSoundPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL: audioURL error: &error];
	require (_clickOpenSoundPlayer, skipAudio);
	[_clickOpenSoundPlayer prepareToPlay];
	
	audioURL = [NSURL fileURLWithPath: [[NSBundle mainBundle] pathForResource: @"ClickClose" ofType: @"wav"]];
	_clickCloseSoundPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL: audioURL error: &error];
	require (_clickCloseSoundPlayer, skipAudio);
	[_clickCloseSoundPlayer prepareToPlay];
	
	// Undo sound.
	audioURL = [NSURL fileURLWithPath: [[NSBundle mainBundle] pathForResource: @"Blip" ofType: @"wav"]];
	_undoSoundPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL: audioURL error: &error];
	require (_undoSoundPlayer, skipAudio);
	[_undoSoundPlayer prepareToPlay];

	// Player won sound.
	audioURL = [NSURL fileURLWithPath: [[NSBundle mainBundle] pathForResource: @"Babip" ofType: @"wav"]];
	_winSoundPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL: audioURL error: &error];
	require (_winSoundPlayer, skipAudio);
	[_winSoundPlayer prepareToPlay];
	
skipAudio:
	
	// Listen for these.
	[[NSNotificationCenter defaultCenter] addObserver: self selector: @selector (cardDragged:) 
			name: StackViewDidDragCardToStackNotification object: nil];
	
	[[NSNotificationCenter defaultCenter] addObserver: self selector: @selector (cardPickedUp:) 
			name: StackViewCardPickedUpNotification object: nil];
	
	[[NSNotificationCenter defaultCenter] addObserver: self selector: @selector (cardReleased:) 
			name: StackViewCardReleasedNotification object: nil];
	
	// Display info view.
	[self performSelector: @selector (info:) withObject: nil afterDelay: 0.5];
	
	// Super.
	[super viewDidLoad];
}

// ------------------------------------------------------------- willRotateToInterfaceOrientation:toInterfaceOrientation

- (void) willRotateToInterfaceOrientation: (UIInterfaceOrientation) orientation duration: (NSTimeInterval) duration
{
	[self adjustLayoutForOrientation: orientation];
}

/*
- (void) willAnimateFirstHalfOfRotationToInterfaceOrientation: (UIInterfaceOrientation) toOrientation duration: (NSTimeInterval) duration
{
}

- (void) didAnimateFirstHalfOfRotationToInterfaceOrientation: (UIInterfaceOrientation) toOrientation
{
}

- (void) willAnimateSecondHalfOfRotationFromInterfaceOrientation: (UIInterfaceOrientation) fromOrientation duration: (NSTimeInterval) duration
{
}
*/

// ------------------------------------------------------------------------------ shouldAutorotateToInterfaceOrientation

- (BOOL) shouldAutorotateToInterfaceOrientation: (UIInterfaceOrientation) orientation
{
	return YES;
}

// --------------------------------------------------------------------------------------------- didReceiveMemoryWarning

- (void) didReceiveMemoryWarning
{
	// Releases the view if it doesn't have a superview.
	[super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

// ------------------------------------------------------------------------------------------------------- viewDidUnload

- (void) viewDidUnload
{
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
	[_newButton release];
	[_undoButton release];
	[_infoButton release];
}

// ------------------------------------------------------------------------------------------------------------- dealloc

- (void) dealloc
{
	// No more observing.
	[[NSNotificationCenter defaultCenter] removeObserver: self];

	// Clean up timers.
	if (_putawayTimer)
		[_putawayTimer invalidate];
	_putawayTimer = nil;
	if (_fadeHintTimer)
		[_fadeHintTimer invalidate];
	_fadeHintTimer = nil;
	
	// Super.
	[super dealloc];
}


#pragma mark ------ alert view delegate methods
//--------------------------------------------------------------------------------------- alertView:clickedButtonAtIndex

- (void) alertView: (UIAlertView *) alertView clickedButtonAtIndex: (NSInteger) buttonIndex
{
	if (alertView.tag == kResetTableAlertTag)
	{
		if (buttonIndex == 1)
		{
			if (_playSounds)
				[_shufflePlayer play];
			
			[self resetTable: nil];
		}
	}
	else if (alertView.tag == kResetStatsAlertTag)
	{
		if (buttonIndex == 1)
		{
			NSUserDefaults	*defaults;
			
			// Get standard defaults.
			defaults = [NSUserDefaults standardUserDefaults];
			
			// Set games played and won values to zero.
			[defaults setObject: [NSNumber numberWithInteger: 0] forKey: @"GamesPlayed"];
			[defaults setObject: [NSNumber numberWithInteger: 0] forKey: @"GamesWon"];
			[defaults synchronize];
			
			// Reflect new game statistics.
			_gamesPlayedLabel.text = [NSString stringWithFormat: @"%d", 0];
			_gamesWonLabel.text = [NSString stringWithFormat: @"%d", 0];
			_gamesWonPercentageLabel.text = @"-";
		}
	}
}

#pragma mark ------ stack view delegate methods
// --------------------------------------------------------------------------------------------- stackView:allowDragCard

- (BOOL) stackView: (CEStackView *) stackView allowDragCard: (CECard *) card
{
	NSUInteger	cardIndex;
	NSUInteger	cardCount;
	NSUInteger	numberOfCardsDragging;
	int			i;
	int			emptyCellCount = 0;
	int			emptyTableauCount = 0;
	CECard		*cardTesting;
	BOOL		allowDrag = NO;
	
	// Skip out if any stack is animating. For example, when the game is wrapping up, a lot of cards are flying up to 
	// the foundation, you would not allow a card to be dragged at this time.
	if ([(CETableView *) self.view animationInProgress])
		return NO;
	
	_restrictedDrag = NO;
	
	// Disallow dragging from the foundation if auto-putaway is true (since, it will just get put up again).
	if ((_autoPutaway) && ([[stackView identifier] isEqualToString: @"Foundation"]))
		return NO;
	
	// The player will always be allowed to drag the top card of a stack.
	if (card == [[stackView stack] topCard])
	{
		allowDrag = YES;
		goto done;
	}
	
	// Get the index of the card attempting to be dragged and the number of cards in the stack.
	cardIndex = [[stackView stack] indexForCard: card];
	cardCount = [[stackView stack] numberOfCards];
	
	// We determine how many cards the player is attenpting to drag.
	numberOfCardsDragging = (cardCount - cardIndex);
	
	// Validate first that each card atop the one attempting to be dragged follows down in rank and alternates in color.
	for (i = cardIndex + 1; i < cardCount; i++)
	{
		cardTesting = [[stackView stack] cardAtIndex: i];
		
		// Can't drag if the color sequence of the stack do not alternate.
		if ([card cardIsOppositeColor: cardTesting] == NO)
			goto done;
		
		// The card rank must increase exactly by one.
		if ((cardTesting.rank + 1) != card.rank)
			goto done;
		
		// This will be the card to test for in the next pass through the loop.
		card = cardTesting;
	}
	
	// See how many empty free-cells there are.
	for (i = 0; i < 4; i++)
	{
		if ([[_cellViews[i] stack] topCard] == nil)
			emptyCellCount = emptyCellCount + 1;
	}
	
	for (i = 0; i < 8; i++)
	{
		if ([[_tableauViews[i] stack] topCard] == nil)
			emptyTableauCount = emptyTableauCount + 1;
	}
	
	// Take into consideration empty cells and allow (empty + 1) cards to be dragged.
	if (emptyTableauCount > 0)
	{
		allowDrag = numberOfCardsDragging <= (emptyCellCount + emptyTableauCount + 1);
		
		// We subtract one from the count of empty tableau columns since one of them could be the destination they drag 
		// to and that would not be possible for the full count of empty cells. We will allow the drag but restrict the 
		// drag to non-empty columns only.
		if ((allowDrag) && (numberOfCardsDragging > (emptyCellCount + emptyTableauCount)))
			_restrictedDrag = YES;
	}
	else
	{
		allowDrag = numberOfCardsDragging <= (emptyCellCount + 1);
	}
	
done:
	
	return allowDrag;
}

// --------------------------------------------------------------------------------- stackView:allowDragCard:toStackView

- (BOOL) stackView: (CEStackView *) stackView allowDragCard: (CECard *) card toStackView: (CEStackView *) dest
{
	CECard	*topDestCard;
	
	// What is the top card on the stack view the pkayer is dragging to?
	topDestCard = [[dest stack] topCard];
	
	// Do we have a top card (if not, we're dragging to an empty stack)?
	if (topDestCard)
	{
		// If there is a card (the destination stack is not empty).
		// Handle the case when the destination stack is the foundation.
		if ([[dest identifier] isEqualToString: @"Foundation"])
		{
			// The card being dragged must be one rank higher than the top card on the foundation, and match its suit.
			if ((card.rank == (topDestCard.rank + 1)) && (card.suit == topDestCard.suit) && ([[stackView stack] topCard] == card))
				return YES;
		}
		else if ([[dest identifier] isEqualToString: @"Cell"])
		{
			// If there is already a card in the cell, the player may not drag another card there.
			return NO;
		}
		else
		{
			// If the stack is the tableau, the rank of the card being dragged must be one smaller and opposite in color.
			return (((card.rank + 1) == topDestCard.rank) && ([card cardIsOppositeColor: topDestCard] == YES));
		}
	}
	else
	{
		// Empty stack. Allow an ace only on foundations, any card may be placed in empty cells or on empty tableua columns.
		if ([[dest identifier] isEqualToString: @"Foundation"])
		{
			// Foundation - since no card on foundation, card must be an Ace.
			if ((card.rank == kCERankAce) && (dest == _foundationViews[card.suit]) && ([[stackView stack] topCard] == card))
				return YES;
		}
		else if ([[dest identifier] isEqualToString: @"Cell"])
		{
			// Cell - only a single card can be dragged, but any one allowed.
			if ([[stackView stack] topCard] == card)
				return YES;
		}
		else
		{
			// Tableau - since no card on tableau, any card allowed (unless a restricted drag).
			if (_restrictedDrag)
				return NO;
			else
				return YES;
		}
	}
	
	return NO;
}

// --------------------------------------------------------------------------------------- stackView:cardWasDoubleTapped

- (void) stackView: (CEStackView *) view cardWasDoubleTapped: (CECard *) card
{
	NSInteger	emptyTableauColumn = -1;
	NSInteger	i;
	BOOL		cardMoved = NO;
	
	// Only double-tap on top card is allowed.
	if ([[view stack] topCard] != card)
		return;
	
	// Disallow double-tapping the foundation if auto-putaway is true (since, it will just get put up again).
	if ((_autoPutaway) && ([[view identifier] isEqualToString: @"Foundation"]))
		return;
	
	// Skip out if any stack is animating.
	if ([(CETableView *) self.view animationInProgress])
		return;
	
	// Check first to see if card can be put up in foundations.
	// We get lucky here in the case of an empty foundation and a souble-tapped ace since -[rank] will return 0.0
	// It would be more programtically elegant and sound to test for topCard == nil and card.rank == ace. Oh well.
	if (([_foundationViews[card.suit].stack topCard].rank + 1) == card.rank)
	{
		[view dealTopCardToStackView: _foundationViews[card.suit] faceUp: YES duration: kAnimationDuration];
		[[NSRunLoop currentRunLoop] runUntilDate: [NSDate dateWithTimeIntervalSinceNow: kAnimationDelay]];
		cardMoved = YES;
		goto done;
	}
	
	// Check next for a match on an occupied tableau column.
	for (i = 0; i < 8; i++)
	{
		CECard	*topCard;
		
		// Get top card for tableau column. Skip if no cards in column
		topCard = [_tableauViews[i].stack topCard];
		if (topCard == nil)
		{
			// Note empty tableau column, we may use it later.
			if (emptyTableauColumn == -1)
				emptyTableauColumn = i;
			continue;
		}
		
		// Test if the top card is of the opposite color and if the rank is one larger than the card tapped on.
		if (((topCard.rank) == card.rank + 1) && ([card cardIsOppositeColor: topCard] == YES))
		{
			[view dealTopCardToStackView: _tableauViews[i] faceUp: YES duration: kAnimationDuration];
			[[NSRunLoop currentRunLoop] runUntilDate: [NSDate dateWithTimeIntervalSinceNow: kAnimationDelay]];
			cardMoved = YES;
			goto done;
		}
	}
	
	// We make a special case for Kings: we look first for an empty tableau column rather than an empty cell.
	if ((card.rank == kCERankKing) && (emptyTableauColumn != -1))
	{
		[view dealTopCardToStackView: _tableauViews[emptyTableauColumn] faceUp: YES duration: kAnimationDuration];
		[[NSRunLoop currentRunLoop] runUntilDate: [NSDate dateWithTimeIntervalSinceNow: kAnimationDelay]];
		cardMoved = YES;
		goto done;
	}
	
	// If the card double-tapped is in a cell already, look first for an empty tableau.
	if ([view.identifier isEqualToString: @"Cell"])
	{
		if (emptyTableauColumn != -1)
		{
			[view dealTopCardToStackView: _tableauViews[emptyTableauColumn] faceUp: YES duration: kAnimationDuration];
			[[NSRunLoop currentRunLoop] runUntilDate: [NSDate dateWithTimeIntervalSinceNow: kAnimationDelay]];
			cardMoved = YES;
			goto done;
		}
	}
	else
	{
		// Failing the above tests, we will look for an empty cell.
		for (i = 0; i < 4; i++)
		{
			// Looking for an empty cell.
			if ([_cellViews[i].stack topCard] == nil)
			{
				[view dealTopCardToStackView: _cellViews[i] faceUp: YES duration: kAnimationDuration];
				[[NSRunLoop currentRunLoop] runUntilDate: [NSDate dateWithTimeIntervalSinceNow: kAnimationDelay]];
				cardMoved = YES;
				goto done;
			}
		}
		
		// No empty cells, then finally use an empty tableau columns if we had previously found one.
		if (emptyTableauColumn != -1)
		{
			[view dealTopCardToStackView: _tableauViews[emptyTableauColumn] faceUp: YES duration: kAnimationDuration];
			[[NSRunLoop currentRunLoop] runUntilDate: [NSDate dateWithTimeIntervalSinceNow: kAnimationDelay]];
			cardMoved = YES;
			goto done;
		}
	}
	
done:
	
	// Indicate a card was moved.
	if ((cardMoved) && (_playedAtleastOneCard == NO))
		[self noteAtleastOneCardMoved];
	
	// Fire off the putaway timer.
	if ((cardMoved) && (_autoPutaway))
	{
		_putawayTimer = [NSTimer scheduledTimerWithTimeInterval: 0.5 target: self 
				selector: @selector (putawayTimer:) userInfo: nil repeats: NO];
	}
}

// --------------------------------------------------------------------------------------------- stackViewOverlayingView

- (UIView *) stackViewOverlayingView: (CEStackView *) view
{
	return _overlayingView;
}

#pragma mark ------ notification methods
// --------------------------------------------------------------------------------------------------------- cardDragged

- (void) cardDragged: (NSNotification *) notification
{
	if (_playedAtleastOneCard == NO)
		[self noteAtleastOneCardMoved];
	
	if (_autoPutaway)
		[self determineIfCardsCanBePutAway];
	
	// See if the game is a wrap.
	[self checkGameState];
}

// -------------------------------------------------------------------------------------------------------- cardPickedUp

- (void) cardPickedUp: (NSNotification *) notification
{
	int		index, initialIndex;
	
	// Skip out if sounds are turned off.
	if (_playSounds == NO)
		return;
	
	index = CERandomInt (kNumCardDrawSounds);
	initialIndex = index;
	while ([_cardDrawPlayers[index] isPlaying])
	{
		index = index + 1;
		if (index >= kNumCardDrawSounds)
			index = 0;
		
		// Bail if we already went around once.
		if (index == initialIndex)
			return;
	}
	
	[_cardDrawPlayers[index] play];
}

// -------------------------------------------------------------------------------------------------------- cardReleased

- (void) cardReleased: (NSNotification *) notification
{
	int		index, initialIndex;
	
	// Skip out if sounds are turned off.
	if (_playSounds == NO)
		return;
	
	index = CERandomInt (kNumCardPlaceSounds);
	initialIndex = index;
	while ([_cardPlacePlayers[index] isPlaying])
	{
		index = index + 1;
		if (index >= kNumCardPlaceSounds)
			index = 0;
		
		// Bail if we already went around once.
		if (index == initialIndex)
			return;
	}
	
	[_cardPlacePlayers[index] play];
}

// -------------------------------------------------------------------------------------------------------- putawayTimer

- (void) putawayTimer: (NSTimer *) timer
{
	// Clean up timer.
	[timer invalidate];
	_putawayTimer = nil;
	
	// See if any cards can be put away.
	[self determineIfCardsCanBePutAway];
	
	// See if the game is a wrap.
	[self checkGameState];
	
	if (_hintState == kHintMoveCardsToFoundation)
		[self displayHint];
}

// ------------------------------------------------------------------------------------------------------------ fadeHint

- (void) fadeHint: (NSTimer *) timer
{
	// Clean up timer.
	[timer invalidate];
	_fadeHintTimer = nil;
	
	_hintState = kHintNone;
	
	[UIView beginAnimations: @"FadeOutHint" context: _currentHintView];
	[UIView setAnimationDelegate: self];
	[UIView setAnimationDidStopSelector: @selector (animationStopped:finished:context:)];
	_currentHintView.alpha = 0.0;
	[UIView commitAnimations];
}

@end
