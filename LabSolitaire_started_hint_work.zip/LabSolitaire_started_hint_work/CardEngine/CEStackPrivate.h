// =====================================================================================================================
//  CEStackPrivate.h
// =====================================================================================================================


#import <UIKit/UIKit.h>
#import "CEStack.h"


@class CECard;


@interface CEStack (CEStackPriv)

- (void) addCardWithoutNotification: (CECard *) card;
- (void) promiseCard: (CECard *) card;
- (void) promiseKeptForCard: (CECard *) card;
- (BOOL) isCardPromised;
- (NSUInteger) numberOfCardsExcludingPromised;
- (NSArray *) cardsExcludingPromised;

@end
